-- Run this entire file in Supabase Dashboard > SQL Editor.
-- Unofficial opinion poll only. Do not use as an official election system.

create table if not exists public.survey_votes (
  id bigint generated always as identity primary key,
  voter_id uuid not null unique references auth.users(id) on delete cascade,
  candidate_id text not null check (candidate_id in (
    'ranjit-kushwaha',
    'umesh-prasad-yadav',
    'bhikhari-pandit',
    'ramjanm-yadav'
  )),
  created_at timestamptz not null default now()
);

alter table public.survey_votes enable row level security;

-- Authenticated users may submit only their own vote.
create policy "authenticated users can cast their own vote"
on public.survey_votes for insert
to authenticated
with check (auth.uid() = voter_id);

-- No public direct reads of individual vote records.
-- No UPDATE or DELETE policies: submitted votes cannot be changed by clients.
revoke all on public.survey_votes from anon, authenticated;
grant insert (voter_id, candidate_id) on public.survey_votes to authenticated;

-- Public aggregate results only; no phone numbers or voter identifiers are returned.
create or replace function public.public_survey_results()
returns table(candidate_id text, votes bigint)
language sql
security definer
set search_path = ''
stable
as $$
  select c.candidate_id, count(v.id)::bigint as votes
  from (values
    ('ranjit-kushwaha'::text),
    ('umesh-prasad-yadav'::text),
    ('bhikhari-pandit'::text),
    ('ramjanm-yadav'::text)
  ) as c(candidate_id)
  left join public.survey_votes v on v.candidate_id = c.candidate_id
  group by c.candidate_id
  order by c.candidate_id;
$$;

revoke all on function public.public_survey_results() from public;
grant execute on function public.public_survey_results() to anon, authenticated;


-- Lets a signed-in user check only whether their own account has voted.
create or replace function public.has_cast_vote()
returns boolean
language sql
security definer
set search_path = ''
stable
as $$
  select exists (
    select 1 from public.survey_votes v
    where v.voter_id = auth.uid()
  );
$$;

revoke all on function public.has_cast_vote() from public;
grant execute on function public.has_cast_vote() to authenticated;
