# SMS OTP Voting Survey (Next.js + Supabase + Vercel)

यह एक **अनौपचारिक जनमत सर्वे** का starter project है। इसमें चार विकल्प, SMS OTP login, प्रति Supabase account एक वोट और सार्वजनिक aggregate results हैं। यह सरकारी चुनाव/आधिकारिक मतदान के लिए नहीं है।

## 1. Supabase project बनाएं
1. Supabase में नया project बनाएं।
2. **SQL Editor** खोलकर `supabase/schema.sql` का पूरा SQL चलाएं।
3. Project Settings → API (या Connect) से Project URL और publishable/anon key लें।
4. Authentication → Sign In / Providers → Phone को enable करें।
5. SMS provider (जैसे Twilio, Supabase द्वारा समर्थित provider) configure करें। Provider के credentials, sender/phone number और SMS settings पूरा करें। SMS provider के बिना असली OTP काम नहीं करेगा।
6. Authentication → Rate Limits में OTP भेजने की सीमा उचित रखें। जरूरत के अनुसार CAPTCHA/bot protection भी सक्षम करें।

## 2. लोकल कंप्यूटर पर चलाएं
Node.js LTS इंस्टॉल होना चाहिए। Project folder में `.env.example` की copy बनाकर उसका नाम `.env.local` रखें और values भरें:

```env
NEXT_PUBLIC_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY
```

फिर terminal में:

```bash
npm install
npm run dev
```

ब्राउज़र में `http://localhost:3000` खोलें।

## 3. Vercel पर publish करें
1. इस folder को GitHub repository में upload करें।
2. Vercel में **Add New → Project** से repository import करें।
3. Project Settings → Environment Variables में ऊपर की दोनों variables जोड़ें।
4. Deploy करें।
5. Supabase Auth URL Configuration में अपनी Vercel deployment URL को Site URL / allowed redirect URLs के रूप में configure करें (OTP flow की आपकी Supabase settings के अनुसार)।

## जरूरी सुरक्षा बातें
- `voter_id` पर database UNIQUE constraint एक Supabase user/account को एक ही वोट देता है; client-side रोक पर निर्भर नहीं है।
- फोन OTP यह साबित करता है कि उपयोगकर्ता उस समय उस नंबर का SMS प्राप्त कर सकता है; यह एक इंसान = एक वोट की पूर्ण गारंटी नहीं है। अलग-अलग नंबरों से duplicate votes संभव हैं।
- Public results केवल candidate-wise counts लौटाते हैं, व्यक्तिगत वोट या फोन नंबर नहीं।
- Supabase `service_role` key को कभी browser code या `NEXT_PUBLIC_` variable में न रखें।
- वास्तविक इस्तेमाल से पहले OTP provider billing, rate limits, bot prevention, privacy notice, data retention और स्थानीय कानूनी आवश्यकताएं जाँचें।
- यह starter public opinion poll है; इसे सरकारी चुनाव के रूप में प्रस्तुत न करें।

## उम्मीदवारों के नाम बदलना
`app/page.tsx` में `candidates` array और `supabase/schema.sql` के allowed candidate IDs को एक साथ अपडेट करें।
