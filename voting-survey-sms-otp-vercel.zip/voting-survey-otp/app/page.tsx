 "use client";

import { useEffect, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/lib/supabase";

const candidates = [
  { id: "ranjit-kushwaha", name: "रंजीत कुशवाहा", letter: "र", color: "blue" },
  { id: "umesh-prasad-yadav", name: "उमेश प्रसाद यादव", letter: "उ", color: "gold" },
  { id: "bhikhari-pandit", name: "भिखारी पड़ित", letter: "भ", color: "green" },
  { id: "ramjanm-yadav", name: "रामजन्म यादव", letter: "रा", color: "purple" }
];

type Result = { candidate_id: string; votes: number };

export default function Home() {
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [selected, setSelected] = useState("");
  const [results, setResults] = useState<Result[]>([]);
  const [hasVoted, setHasVoted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) setUser(data.user);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    loadResults();
  }, []);

  useEffect(() => {
    if (user) checkVote();
    else setHasVoted(false);
  }, [user]);

  async function loadResults() {
    if (!supabase) return;
    const { data, error } = await supabase.rpc("public_survey_results");
    if (!error && data) setResults(data as Result[]);
  }

  async function checkVote() {
    if (!supabase || !user) return;
    const { data, error } = await supabase.rpc("has_cast_vote");
    if (!error) setHasVoted(Boolean(data));
  }

  async function sendOtp(e: React.FormEvent) {
    e.preventDefault(); setError(""); setMessage("");
    if (!supabase) { setError("पहले Supabase की .env.local सेटिंग पूरी करें।"); return; }
    const normalized = phone.replace(/[^\d+]/g, "");
    if (!/^\+[1-9]\d{7,14}$/.test(normalized)) {
      setError("मोबाइल नंबर country code के साथ लिखें, जैसे भारत के लिए +91XXXXXXXXXX।"); return;
    }
    setLoading(true);
    const { error } = await supabase.auth.signInWithOtp({ phone: normalized });
    setLoading(false);
    if (error) setError("OTP नहीं भेजा जा सका: " + error.message);
    else { setPhone(normalized); setOtpSent(true); setMessage("SMS OTP भेजने का अनुरोध किया गया है। SMS provider सेट होना जरूरी है।"); }
  }

  async function verifyOtp(e: React.FormEvent) {
    e.preventDefault(); setError(""); setMessage("");
    if (!supabase) return;
    setLoading(true);
    const { data, error } = await supabase.auth.verifyOtp({ phone, token: otp.trim(), type: "sms" });
    setLoading(false);
    if (error) setError("OTP सत्यापित नहीं हुआ: " + error.message);
    else {
      setUser(data.user);
      setMessage("मोबाइल नंबर सत्यापित हो गया। अब अपना विकल्प चुनें।");
      setOtpSent(false);
    }
  }

  async function submitVote() {
    setError(""); setMessage("");
    if (!supabase || !user) { setError("वोट देने से पहले मोबाइल OTP सत्यापित करें।"); return; }
    if (!selected) { setError("कृपया एक उम्मीदवार चुनें।"); return; }
    setLoading(true);
    const { error } = await supabase.from("survey_votes").insert({
      voter_id: user.id,
      candidate_id: selected
    });
    setLoading(false);
    if (error) {
      if (error.code === "23505" || error.code === "42501") {
        setHasVoted(true);
        setError("इस सत्यापित अकाउंट से वोट पहले ही दर्ज हो चुका है, या वोटिंग अनुमति उपलब्ध नहीं है।");
      } else setError("वोट दर्ज नहीं हो सका: " + error.message);
    } else {
      setHasVoted(true);
      setMessage("आपका वोट सफलतापूर्वक दर्ज हो गया। धन्यवाद!");
      await loadResults();
    }
  }

  async function signOut() {
    if (!supabase) return;
    await supabase.auth.signOut();
    setUser(null); setOtp(""); setOtpSent(false); setSelected(""); setMessage("आप लॉगआउट हो गए हैं।");
  }

  const total = results.reduce((sum, r) => sum + Number(r.votes || 0), 0);
  const voteFor = (id: string) => Number(results.find(r => r.candidate_id === id)?.votes || 0);

  return (
    <main>
      <header className="topbar">
        <div className="brandmark">✓</div>
        <div><div className="brand">जनमत सर्वेक्षण</div><div className="brand-sub">आपकी राय • आपकी आवाज़</div></div>
      </header>
      <section className="hero">
        <span className="eyebrow">ऑनलाइन जनमत सर्वे</span>
        <h1>आपकी पसंद का उम्मीदवार कौन है?</h1>
        <p>एक उम्मीदवार चुनें। वोट देने के लिए मोबाइल SMS OTP से सत्यापन आवश्यक है।</p>
      </section>
      {!supabase && <div className="alert error">सेटअप अधूरा है: Supabase Project URL और Publishable/Anon Key को Vercel Environment Variables या स्थानीय <code>.env.local</code> में जोड़ें।</div>}
      <div className="grid">
        <section className="card">
          <div className="section-title"><span className="step">1</span><div><h2>मोबाइल सत्यापन</h2><p>OTP पाने के लिए country code सहित नंबर लिखें।</p></div></div>
          {!user ? (
            <>
              {!otpSent ? <form onSubmit={sendOtp}>
                <label htmlFor="phone">मोबाइल नंबर</label>
                <input id="phone" type="tel" inputMode="tel" placeholder="+91XXXXXXXXXX" value={phone} onChange={e => setPhone(e.target.value)} required />
                <button className="primary" disabled={loading || !supabase}>{loading ? "कृपया प्रतीक्षा करें…" : "SMS OTP भेजें"}</button>
              </form> : <form onSubmit={verifyOtp}>
                <label htmlFor="otp">SMS से मिला OTP</label>
                <input id="otp" inputMode="numeric" autoComplete="one-time-code" maxLength={8} placeholder="OTP दर्ज करें" value={otp} onChange={e => setOtp(e.target.value)} required />
                <button className="primary" disabled={loading}>{loading ? "सत्यापन हो रहा है…" : "OTP सत्यापित करें"}</button>
                <button type="button" className="text-button" onClick={() => {setOtpSent(false);setOtp("");}}>नंबर बदलें</button>
              </form>}
            </>
          ) : <div className="verified"><span className="check">✓</span><div><strong>मोबाइल सत्यापित</strong><p>{user.phone || "Verified account"}</p></div><button className="text-button" onClick={signOut}>लॉगआउट</button></div>}
          <div className="divider"></div>
          <div className="section-title"><span className="step">2</span><div><h2>अपना वोट दें</h2><p>केवल एक विकल्प चुन सकते हैं।</p></div></div>
          <div className="candidates">
            {candidates.map(c => <label key={c.id} className={`candidate ${selected === c.id ? "selected" : ""} ${!user || hasVoted ? "locked" : ""}`}>
              <input type="radio" name="candidate" value={c.id} checked={selected === c.id} disabled={!user || hasVoted} onChange={() => setSelected(c.id)} />
              <span className={`avatar ${c.color}`}>{c.letter}</span>
              <span className="candidate-name">{c.name}</span>
              <span className="radio-mark"></span>
            </label>)}
          </div>
          <button className="primary vote-button" disabled={!user || hasVoted || loading || !selected} onClick={submitVote}>
            {hasVoted ? "✓ आपका वोट दर्ज है" : loading ? "वोट दर्ज हो रहा है…" : "वोट सबमिट करें"}
          </button>
          {hasVoted && <p className="success-inline">इस सत्यापित अकाउंट से वोट पहले ही दर्ज है।</p>}
          {message && <div className="alert success" role="status">{message}</div>}
          {error && <div className="alert error" role="alert">{error}</div>}
        </section>
        <section className="card results-card">
          <div className="results-heading"><div><span className="eyebrow">सार्वजनिक परिणाम</span><h2>वोटिंग रिजल्ट</h2></div><span className="live-dot">LIVE</span></div>
          <p className="result-total"><strong>{total}</strong> कुल दर्ज वोट</p>
          {candidates.map(c => {
            const votes = voteFor(c.id);
            const pct = total ? Math.round(votes / total * 100) : 0;
            return <div className="result-row" key={c.id}>
              <div className="result-label"><strong>{c.name}</strong><span>{pct}% <small>({votes})</small></span></div>
              <div className="track"><div className={`bar ${c.color}`} style={{width: `${pct}%`}} /></div>
            </div>;
          })}
          <button className="secondary" onClick={loadResults}>रिजल्ट रीफ्रेश करें ↻</button>
          <p className="disclaimer"><strong>महत्वपूर्ण सूचना:</strong> यह केवल अनौपचारिक जनमत सर्वे है, सरकारी चुनाव या आधिकारिक मतदान नहीं। एक फोन नंबर/अकाउंट पर एक वोट लागू करने के लिए SMS OTP और डेटाबेस नियम इस्तेमाल होते हैं; यह व्यक्ति की वास्तविक पहचान की गारंटी नहीं है।</p>
        </section>
      </div>
      <footer>जनमत सर्वेक्षण · अनौपचारिक राय-संग्रह</footer>
    </main>
  );
}
