import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Public Opinion Survey",
  description: "An unofficial community opinion poll with SMS OTP verification."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="hi"><body>{children}</body></html>;
}
